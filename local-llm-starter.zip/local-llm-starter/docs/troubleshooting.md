# Troubleshooting

## Ollama is not found

Run:

```bash
ollama --version
```

If the command is unavailable, install Ollama and make sure it is running.

## Open WebUI does not load

Check the container:

```bash
docker compose ps
```

View logs:

```bash
docker compose logs -f
```

## The model is slow

Local inference speed depends on hardware, model size, quantization, context length, and other workloads. Try a smaller model first.

## How do I stop Open WebUI?

```bash
docker compose down
```

Your named Docker volume is retained unless you explicitly remove it.
