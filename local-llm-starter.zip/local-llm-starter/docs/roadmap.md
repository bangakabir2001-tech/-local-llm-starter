# Roadmap

## Phase 1 — Foundation
- Local Ollama installation
- Open WebUI
- Reproducible Docker configuration
- Basic documentation

## Phase 2 — Development
- Python client/API example
- Model configuration examples
- Prompt templates
- Basic logging

## Phase 3 — Experiments
- Compare model response quality
- Measure latency and resource usage
- Test structured outputs
- Explore RAG with local documents

## Phase 4 — Practical applications
- Business-document summarization
- Data-analysis assistance
- Local knowledge bases
- Workflow automation
