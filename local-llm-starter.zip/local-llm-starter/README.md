# Local LLM Starter

A beginner-friendly setup for running open-source large language models locally with **Ollama** and **Open WebUI**.

## Why this project?

Cloud AI tools are powerful, but local models are useful when learning about AI infrastructure, experimenting with prompts, and keeping development workflows under the user's control. This project documents a simple, reproducible starting point for students and developers who want to explore local LLMs.

## What it provides

- Ollama for downloading and running local language models
- Open WebUI for a browser-based chat interface
- Docker Compose for a reproducible Open WebUI deployment
- Basic troubleshooting and model-management guidance
- A foundation for adding automation, RAG, document processing, and evaluation later

## Requirements

- macOS, Linux, or Windows
- Docker Desktop
- Ollama
- Enough RAM/storage for the model you choose

## Quick start

### 1. Install Ollama

Install Ollama from the official website, then verify:

```bash
ollama --version
```

### 2. Download a model

For example:

```bash
ollama pull llama3.2
```

You can choose another model supported by your hardware.

### 3. Test the model

```bash
ollama run llama3.2
```

### 4. Start Open WebUI

```bash
docker compose up -d
```

Then open Open WebUI in your browser at:

`http://localhost:3000`

The first launch may take a little time while the container starts.

## Project structure

```text
local-llm-starter/
├── README.md
├── docker-compose.yml
├── .gitignore
├── LICENSE
└── docs/
    ├── troubleshooting.md
    └── roadmap.md
```

## Roadmap

- [x] Document a basic local LLM setup
- [x] Add Docker Compose configuration
- [x] Add troubleshooting notes
- [ ] Add model benchmarking
- [ ] Add a simple Python API example
- [ ] Add document/RAG experiments
- [ ] Add prompt evaluation examples
- [ ] Compare local models on common tasks

## Disclaimer

This is an educational and experimental project. Model performance depends heavily on the model, hardware, quantization, context length, and workload.

## Author

Kabir Singh Banga

Master's student in Business & Economics at TU Chemnitz, exploring practical applications of AI, automation, data, and locally hosted technologies.
